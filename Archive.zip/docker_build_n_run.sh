docker build --tag dalbot .
docker run -d dalbot
